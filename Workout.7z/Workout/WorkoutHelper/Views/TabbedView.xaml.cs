﻿using System.Windows.Controls;

namespace WorkoutHelper.Views
{
    /// <summary>
    /// Interaction logic for TabbedView.xaml
    /// </summary>
    public partial class TabbedView : UserControl
    {
        public TabbedView()
        {
            InitializeComponent();
        }
    }
}
