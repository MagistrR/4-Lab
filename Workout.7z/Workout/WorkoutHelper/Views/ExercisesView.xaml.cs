﻿using System.Windows.Controls;

namespace WorkoutHelper.Views
{
    /// <summary>
    /// Interaction logic for ExercisesView.xaml
    /// </summary>
    public partial class ExercisesView : UserControl
    {
        public ExercisesView()
        {
            InitializeComponent();
        }
    }
}
