﻿using System.Windows.Controls;

namespace WorkoutHelper.Views
{
    /// <summary>
    /// Interaction logic for PlanningView.xaml
    /// </summary>
    public partial class PlanningView : UserControl
    {
        public PlanningView()
        {
            InitializeComponent();
        }
    }
}
