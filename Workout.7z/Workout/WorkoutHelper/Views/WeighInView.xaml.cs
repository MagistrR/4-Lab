﻿using System.Windows.Controls;

namespace WorkoutHelper.Views
{
    /// <summary>
    /// Interaction logic for WeighInView.xaml
    /// </summary>
    public partial class WeighInView : UserControl
    {
        public WeighInView()
        {
            InitializeComponent();
        }
    }
}
