﻿namespace WorkoutHelper.Interfaces
{
    public interface IConfigurationDataService
    {
        string DatabaseConnectionString { get; set; }
    }
}
