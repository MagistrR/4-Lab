﻿namespace WorkoutHelper.Models
{
    public class EquipmentCategory
    {
        public string Name { get; set; }

        public bool Selected { get; set; }
    }
}
