﻿using Prism.Events;

namespace WorkoutHelper.Events
{
    public class SettingsChangedEvent: PubSubEvent
    {
    }
}
