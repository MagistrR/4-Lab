﻿using Prism.Events;

namespace WorkoutHelper.Events
{
    public class LoginRequestEvent: PubSubEvent<int>
    {
    }
}
